﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

//AMPN set is associated only with the preceding set.
//(b) The NARR set is associated with the preceding group of sets.
//(c) The RMKS

namespace NHTest
{
    public partial class Form1 : Form
    {
        string workingPath = "";
        List<string> setIDList = new List<string>();
        string lastHtmlFile = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            string directoryPath = textBox1.Text;
            workingPath = textBox1.Text;

            string outputXmlFilePath = "output.xml";

     
            using (XmlWriter writer = XmlWriter.Create(outputXmlFilePath, new XmlWriterSettings { Indent = true }))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("Rows");

 
                var htmlFiles = Directory.GetFiles(directoryPath, "*.HTM");

                if (htmlFiles != null) 
                {
                    richTextBox1.AppendText("html files ");
                    foreach (var htmlFile in htmlFiles)
                    {
                        richTextBox1.AppendText(htmlFile);
                    }
                }

                foreach (var htmlFile in htmlFiles)
                {
                    lastHtmlFile = htmlFile;

                    ProcessHtmlFile(htmlFile, writer);
                }

                writer.WriteEndElement(); // Rows
                writer.WriteEndDocument();
            }

            Console.WriteLine("XML dosyası başarıyla oluşturuldu.");
        }

        HtmlNode FindSegmentTable(HtmlAgilityPack.HtmlDocument doc)
        {

            var tables = doc.DocumentNode.SelectNodes("//table");


            foreach (var table in tables)
            {
                var header = table.SelectSingleNode(".//tr/td/div[contains(text(), 'SEG')]");

                if (header != null)
                {
                    return table; 
                }
            }
            return null; 
        }

        HtmlNode FindSubTable(HtmlAgilityPack.HtmlDocument doc)
        {
          
            var tables = doc.DocumentNode.SelectNodes("//table");

           
            foreach (var table in tables)
            {
                var header = table.SelectSingleNode(".//tr/td/div[contains(text(), 'DESIGNATOR')]");

                if (header != null)
                {
                    return table; 
                }
            }
            return null; 
        }


        void ProcessHtmlFile(string htmlFilePath, XmlWriter writer)
        {
           
            var htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.Load(htmlFilePath);
           

            var table = FindSegmentTable(htmlDoc);

            if (table != null)
            {
              
                WriteTableDataToXml(table, writer);
            }
        }

        void ProcessSubHtmlFile(string htmlFilePath, XmlWriter writer)
        {
            var htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.Load(htmlFilePath);

            var table = FindSubTable(htmlDoc);

            
        }

        
        void WriteTableDataToXml(HtmlNode table, XmlWriter writer)
        {
           
            var rows = table.SelectNodes(".//tr[@class='normal']");

            foreach (var row in rows)
            {
                
                var cells = row.SelectNodes(".//td");

                if(cells.Count > 0)
                {
                    if(!setIDList.Contains(cells[3].InnerText.Trim()))
                    {
                        setIDList.Add(cells[3].InnerText.Trim());                 

          
                        if (cells != null && cells.Count > 0)
                        {
                            writer.WriteStartElement("Row");

                            writer.WriteAttributeString("SETID", cells[3].InnerText.Trim());
                            writer.WriteAttributeString("SEQ", cells[4].InnerText.Trim());
                            writer.WriteAttributeString("CLS", cells[5].InnerText.Trim());
                            writer.WriteAttributeString("SET_FORMAT_NAME", cells[6].InnerText.Trim());
                            writer.WriteAttributeString("REMARKS", cells[7].InnerText.Trim());

                  
                            var linkNode = cells[3].SelectSingleNode(".//a");
                            richTextBox1.AppendText("link Node:" + linkNode);
                            var link = "";
                            if (linkNode != null)
                            {
                                writer.WriteAttributeString("HREF", linkNode.GetAttributeValue("href", ""));
                                link = linkNode.GetAttributeValue("href", "");
                                richTextBox1.AppendText("link:" + link);
                            }

                            if(link.Length > 0)
                            {
                                var SubFileName = workingPath + "\\" + link.Split("#").First();
                                if (!File.Exists(SubFileName))
                                {
                                    richTextBox1.AppendText("sub file is not exist:" + SubFileName);
                                }
                                var htmlDoc = new HtmlAgilityPack.HtmlDocument();
                                htmlDoc.Load(SubFileName);

                                var subTable = FindSubTable(htmlDoc);
                                var subRows = subTable.SelectNodes(".//tr[@class='normal']");
                                var LastDesignator = "";
                                int lastCellCount = 0;

                                foreach (var subRow in subRows)
                                {
                                    var subCells = subRow.SelectNodes(".//td");

                                    if (subCells != null && subCells.Count > 0)
                                    {
                                        if (lastCellCount == 7)
                                        {
                                            if (subCells.Count == 6 || subCells.Count == 4)
                                            {
                                                writer.WriteEndElement();
                                            }
                                        }

                                        if (subCells.Count == 6)
                                        {
                                            writer.WriteStartElement("SubRow");

                                            try
                                            {
                                                writer.WriteAttributeString("DESIGNATOR", subCells[1].InnerText.Replace("\0","").Trim());
                                                writer.WriteAttributeString("TABLE", subCells[2].InnerText.Replace("\0", "").Trim());
                                                writer.WriteAttributeString("CLS", subCells[3].InnerText.Replace("\0","").Trim());
                                                writer.WriteAttributeString("FLDDESC", subCells[4].InnerText.Replace("\0","").Trim());
                                                writer.WriteAttributeString("EXPLANATION", subCells[5].InnerText.Replace("\0","").Trim());
                                                writer.WriteEndElement();
                                            }
                                            catch (Exception ex)
                                            {
                                                Console.WriteLine(ex.Message);
                                                richTextBox1.AppendText(ex.Message);
                                                writer.WriteEndElement();

                                            }
                                            
                                        }
                                        else if (subCells.Count == 4)
                                        {
                                            writer.WriteStartElement("SubRow");
                                            writer.WriteAttributeString("DESIGNATOR", subCells[1].InnerText.Trim());
                                            writer.WriteAttributeString("TABLE", subCells[2].InnerText.Trim());
                                            writer.WriteAttributeString("CLS", subCells[3].InnerText.Trim());
                                            LastDesignator = subCells[1].InnerText;
                                        }
                                        else if (subCells.Count == 7)
                                        {
                                            writer.WriteStartElement("SubRowType");
                                            writer.WriteAttributeString("DESIGNATOR", subCells[2].InnerText.Trim());
                                            writer.WriteAttributeString("TABLE", subCells[3].InnerText.Trim());
                                            writer.WriteAttributeString("CLS", subCells[4].InnerText.Trim());
                                            writer.WriteAttributeString("FLDDESC", subCells[5].InnerText.Trim());
                                            writer.WriteAttributeString("EXPLANATION", subCells[6].InnerText.Trim());
                                            writer.WriteAttributeString("PARENTDESIGNATOR", LastDesignator);
                                            writer.WriteEndElement();
                                        }

                                        lastCellCount = subCells.Count;

                                    }
                                }

                                if (lastCellCount == 7)
                                {
                                    writer.WriteEndElement();
                                }
                            }                            

                            writer.WriteEndElement(); 
                        }

                    }
                }
              
            }
        }
    }
}
