﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATOParser
{
    internal class Row
    {        
        public string SETID { get; set; }

        public string SEQ { get; set; }
        public string SETFORMATNAME { get; set; }

        public string CLS { get; set; }

        public string Explanation { get; set; }

        public List<SubRow> subRows { get; set; }
    }
}
