﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace ATOParser
{
    internal class SourceCreator
    {
        public List<Row> Rows;

        public void CreateSource()
        {
            Rows = new List<Row>();

            var fileName = "output.xml";

            if (!File.Exists(fileName))
            {
                Console.WriteLine("File is not exist! File name:" + fileName);
            }

            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                xmlDoc.Load(fileName);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return;
            }

            XElement rootElement = XElement.Load(fileName);

            var rowElements = rootElement.Elements("Row");

            foreach (var rowElement in rowElements)
            {
                Row row = new Row();

                row.SETID = rowElement.Attribute("SETID")?.Value;
                row.SEQ = rowElement.Attribute("SEQ")?.Value;
                row.CLS = rowElement.Attribute("CLS")?.Value;
                row.SETFORMATNAME = rowElement.Attribute("SET_FORMAT_NAME")?.Value;
                row.SETFORMATNAME = row.SETFORMATNAME.ToLowerInvariant().Replace(" ", "_");
                row.SETFORMATNAME = row.SETFORMATNAME.ToLowerInvariant().Replace("-", "_");
                row.Explanation = rowElement.Attribute("REMARKS")?.Value;

                var subRowElements = rowElement.Elements("SubRow");

                List<SubRow> subRows = new List<SubRow>();

                foreach (var subRowElement in subRowElements)
                {
                    SubRow subRow = new SubRow();

                    subRow.Designator = subRowElement.Attribute("DESIGNATOR")?.Value;
                    subRow.Designator = subRow.Designator.ToLowerInvariant().Replace(",", "");
                    subRow.Designator = subRow.Designator.ToLowerInvariant().Replace(" ", "_");
                    subRow.Table = subRowElement.Attribute("TABLE")?.Value;
                    subRow.CLS = subRowElement.Attribute("CLS")?.Value;
                    subRow.FLDDESC = subRowElement.Attribute("FLDDESC")?.Value;
                    subRow.Explanation = subRowElement.Attribute("Explanation")?.Value;


                    List<SubRowType> subRowTypes = new List<SubRowType>();
                    var subRowTypeElements = subRowElement.Elements("SubRowType");


                    foreach (var subRowTypeElement in subRowTypeElements)
                    {
                        SubRowType subRowType = new SubRowType();
            
                        subRowType.Designator = subRowTypeElement.Attribute("DESIGNATOR")?.Value;
                        subRowType.Table = subRowTypeElement.Attribute("TABLE")?.Value;
                        subRowType.CLS = subRowTypeElement.Attribute("CLS")?.Value;
                        subRowType.FLDDESC = subRowTypeElement.Attribute("FLDDESC")?.Value;
                        subRowType.Explanation = subRowTypeElement.Attribute("Explanation")?.Value;

                        subRowTypes.Add(subRowType);
                    }

                    subRow.subRowTypes = subRowTypes;
                    subRows.Add(subRow);
                }

                row.subRows = subRows;
                Rows.Add(row);
            }
        }
    }
}
