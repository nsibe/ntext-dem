﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace ATOParser
{
    internal class AtoConverter
    {
        public string inputText {  get; set; }
        public string outputText { get; set; }
        public SourceCreator creator { get; set; }
        

        public AtoConverter() 
        {
           creator = new SourceCreator();
           creator.CreateSource();
        }

        public string Convert()
        {
            StringBuilder sb = new StringBuilder();
            using (StringWriter stringWriter = new StringWriter(sb))
            {
                using (XmlWriter writer = XmlWriter.Create(stringWriter, new XmlWriterSettings { Indent = true }))
                {
                    writer.WriteStartDocument();
                    string prefix = "ns2";
                    string url = "air_tasking_order";
                    writer.WriteStartElement(prefix, "air_tasking_order", "urn:nato:mtf:bl:11.0:ato");

                    string[] splitArray = inputText.Split(new string[] { "//" }, StringSplitOptions.None);
                    string[] splitLines = inputText.Split(new string[] { "\n" }, StringSplitOptions.None);
                    List<string> array = new List<string>(splitArray);
                    List<string> lines = new List<string>(splitLines);

                    List<string> output = new List<string>();

                    
                    for (int i = 0; i < array.Count; i++)
                    {
                        string item = array[i];
                        if (item != null && item.Trim().Length != 0)
                        {
                            bool ampn = false;
                            string ampnItem = "";

                            if(i<= array.Count -2)
                            {
                                ampnItem = array[i+1];

                                if(ampnItem.Trim().StartsWith("AMPN"))
                                {
                                    string[] ampnArray = ampnItem.Split(new string[] { "/" }, StringSplitOptions.None);
                                    if(ampnArray.Length > 1)
                                    {
                                        ampnItem = ampnArray[1]; 
                                        ampn = true;
                                    }
                                }

                            }
                            ConvertSingleLine(writer, item.Trim(),ampn, ampnItem);
                        }
                    }

                    writer.WriteEndElement(); // air_tasking_order
                    writer.WriteEndDocument();

                }
            }

            return sb.ToString();
        }

        public void ConvertTimeFrame(XmlWriter writer, string input)
        {
            string[] parts = input.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length > 2)
            {
                string from = parts[1].Substring(5); // "FROM:050001ZSEP2024"
                string to = parts[2].Substring(3);   // "TO:052359ZSEP2024"

                // FROM kısmını parçala
                string dayFrom = from.Substring(0, 2);
                string hourFrom = from.Substring(2, 2);
                string minuteFrom = from.Substring(4, 2);
                string monthFrom = from.Substring(8, 3);
                string yearFrom = from.Substring(11, 4);
                string timeZone = from.Substring(5, 1);

                // TO kısmını parçala
                string dayTo = to.Substring(0, 2);
                string hourTo = to.Substring(2, 2);
                string minuteTo = to.Substring(4, 2);
                string monthTo = to.Substring(8, 3);
                string yearTo = to.Substring(11, 4);
                string timeZoneTo = to.Substring(5, 1);


                // XML oluştur
                XElement xml = new XElement("TimeRange",
                    new XElement("From",
                        new XElement("Day", dayFrom),
                        new XElement("Hour", hourFrom),
                        new XElement("Minute", minuteFrom),
                        new XElement("Month", monthFrom),
                        new XElement("Year", yearFrom)
                    ),
                    new XElement("To",
                        new XElement("Day", dayTo),
                        new XElement("Hour", hourTo),
                        new XElement("Minute", minuteTo),
                        new XElement("Month", monthTo),
                        new XElement("Year", yearTo)
                    )
                );
            }
        }

        public void ParseDateTimeSpan(XmlWriter writer, string input)
        {
            string[] parts = input.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length > 2)
            {
                string from = parts[1].Substring(5); // "FROM:050001ZSEP2024"
                string to = parts[2].Substring(3);   // "TO:052359ZSEP2024"

                WriteDateTimeSpan(writer, from, true);
                WriteDateTimeSpan(writer, to, false);
            }

        }

        public void WriteDateTimeSpan(XmlWriter writer, string input, bool start = false)
        {
      
            string day = input.Substring(0, 2);
            string hour = input.Substring(2, 2);
            string minute = input.Substring(4, 2);
            string month = input.Substring(8, 3);
            string year = input.Substring(10, 4);
            string timeZone = input.Substring(5, 1);


            if(start)
            {
                writer.WriteStartElement("date_time_group_of_start");

            }
            else
            {
                writer.WriteStartElement("date_time_group_of_stop");

            }

            writer.WriteStartElement("day");
            writer.WriteValue(day);
            writer.WriteEndElement();

            writer.WriteStartElement("hour_time");
            writer.WriteValue(hour);
            writer.WriteEndElement();

            writer.WriteStartElement("minute_time");
            writer.WriteValue(minute);
            writer.WriteEndElement();

            writer.WriteStartElement("time_zone");
            writer.WriteValue(timeZone);
            writer.WriteEndElement();

            writer.WriteStartElement("month_name");
            writer.WriteValue(day);
            writer.WriteEndElement();

            writer.WriteStartElement("year");
            writer.WriteValue(year);
            writer.WriteEndElement();

            writer.WriteEndElement();
        }

        public string ConvertSingleLine(XmlWriter writer, string input, bool AMPN = false, string AMPNInput="")
        {

            string[] lineItems = input.Split(new string[] { "/" }, StringSplitOptions.None);
            string result = "";

            List<string> items = new List<string>(lineItems);

            if(items.Count > 0)
            {                
                String firstItem = items[0];
                
                Row row = creator.Rows.FirstOrDefault(rowItem =>  rowItem.SETID == firstItem);

                if (row != null) 
                {
                    if (row.SETID == "TIMEFRAM")
                    {
                        writer.WriteStartElement(row.SETFORMATNAME);
                        writer.WriteAttributeString("setId", firstItem);

                        if(AMPN)
                        {
                            writer.WriteStartElement("amplification");
                            writer.WriteAttributeString("setId", "AMPN");
                            writer.WriteStartElement("free_text");
                            writer.WriteValue(AMPNInput);
                            writer.WriteEndElement();
                            writer.WriteEndElement();
                        }


                      
                        ParseDateTimeSpan(writer, input);


                        writer.WriteEndElement();
                    }
                    else if (row.SETID == "HEADING")
                    {
                        writer.WriteStartElement(items[1].ToLower().ToLowerInvariant().Replace(" ","_").Trim());
                        writer.WriteAttributeString("setId", firstItem);
                        writer.WriteStartElement(row.SETFORMATNAME);
                        writer.WriteValue(items[1]);
                        writer.WriteEndElement();
                        writer.WriteEndElement();

                    }
                    else 
                    {
                        writer.WriteStartElement(row.SETFORMATNAME);
                        writer.WriteAttributeString("setId", firstItem);

                        int lineSubItemCount = items.Count;
                        int rowSubItemCount = row.subRows.Count;

                        if (lineSubItemCount - 1 <= rowSubItemCount)
                        {
                            for (int i = 1; i < lineSubItemCount; i++)
                            {
                                if (items[i] != "-")
                                {
                                    writer.WriteStartElement(row.subRows[i - 1].Designator, items[i]);
                                    writer.WriteValue(items[i]);
                                    writer.WriteEndElement();
                                }
                            }
                        }

                        writer.WriteEndElement(); // Row
                    }                   
                }
                
            }
            return result;
        }

    }
}
