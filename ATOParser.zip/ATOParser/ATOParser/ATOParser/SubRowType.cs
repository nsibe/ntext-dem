﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATOParser
{
    internal class SubRowType
    {
        public string KeyWord { get; set; }
        public string Designator { get; set; }
        public string Explanation { get; set; }
        public string FLDDESC { get; set; }
        public string Table { get; set; }
        public string CLS { get; set; }
        public string ParentDesignator { get; set; }
    }
}
