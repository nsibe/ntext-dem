﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATOParser
{
    public partial class Form1 : Form
    {
        string fileName = "";
        string fileText = "";
        SourceCreator creator;

        public Form1()
        {
            InitializeComponent();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Select a text file";
            openFileDialog.CheckFileExists = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK) 
            {
                fileName = openFileDialog.FileName;
                Console.WriteLine(fileName);
                if (File.Exists(fileName)) 
                { 
                    richTextBox1.Text = File.ReadAllText(fileName);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
           AtoConverter converter = new AtoConverter();
           converter.inputText = richTextBox1.Text;

            richTextBox2.Text = converter.Convert();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            creator = new SourceCreator();
            creator.CreateSource();

            int count = creator.Rows.Count;
            int l = 9;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
